/* ESERCIZIO FINE MODULO SQL */

CREATE SCHEMA toysgroup;
USE toysgroup;

CREATE TABLE Product (
ProductID int not null auto_increment,
ProductName varchar(150) not null,
Category varchar(150) not null,
UnitPrice decimal(13,2),
primary key (ProductID)
);

CREATE TABLE Region (
RegionID INT not null auto_increment,
RegionName varchar(250) not null,
Country varchar(250) not null,
primary key (RegionID)
);

CREATE TABLE Sales (
ID_transaction int not null auto_increment,
Date_transaction date not null,
Quantity int not null,
Tot_paid decimal(13,2) not null,
ProductID int not null,
RegionID int not null,
primary key (ID_transaction),
foreign key (ProductID) references Product(ProductID),
foreign key (RegionID) references Region(RegionID)
);

/* popolare le tabelle */

INSERT INTO Product (ProductName, Category, UnitPrice) VALUES
('Toy Car', 'Vehicles', 10.99),
('Barbie', 'Doll', 15.49),
('Risiko', 'Board Game', 29.99),
('Puzzle', 'Games', 9.99),
('Action Figure', 'Figures', 12.99),
('Monopoly', 'Board Game', 24.99),
('Toy Train', 'Vehicles', 19.99),
('Cards Against Humanity', 'Board Game', 59.99),
('Bratz', 'Doll', 14.99),
('Science Kit', 'Educational', 34.99),
('Art Set', 'Creative', 22.99),
('Lego Set', 'Construction', 49.99);

INSERT INTO Region (RegionName, Country) VALUES
('North America', 'USA'),
('Europe', 'Germany'),
('Asia', 'China'),
('South America', 'Brazil'),
('Africa', 'Nigeria'),
('Oceania', 'Australia'),
('Middle East', 'UAE'),
('Eastern Europe', 'Russia'),
('Northern Europe', 'Sweden'),
('Western Europe', 'France'),
('Southern Europe', 'Malta'),
('Central America', 'Mexico');

INSERT INTO Sales (Date_transaction, Quantity, Tot_paid, ProductID, RegionID) VALUES
('2023-01-15', 10, 109.90, 1, 1),
('2024-02-20', 5, 77.45, 2, 2),
('2023-03-12', 23, 89.97, 3, 3),
('2023-04-25', 7, 69.93, 4, 4),
('2024-05-05', 8, 103.92, 5, 5),
('2024-06-18', 4, 99.96, 6, 6),
('2024-07-22', 6, 119.94, 7, 7),
('2023-08-30', 12, 119.98, 8, 8),
('2024-09-10', 9, 134.91, 9, 9),
('2024-10-14', 3, 104.97, 10, 10),
('2024-11-21', 5, 114.95, 11, 11),
('2023-12-01', 4, 199.96, 12, 12);

/*DOMANDA 1: Verificare che i campi definiti come PK siano univoci.*/

SELECT ProductID, COUNT(ProductID) AS frequency
FROM product
GROUP BY ProductID
HAVING frequency > 1;

SELECT RegionID, COUNT(RegionID) AS frequency
FROM Region
GROUP BY RegionID
HAVING frequency > 1;

SELECT ID_transaction, COUNT(ID_transaction) AS frequency
FROM Sales
GROUP BY ID_transaction
HAVING frequency > 1;

/*DOMANDA 2: Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.*/

-- INPUT product name, annual revenue, year
-- OUTPUT nome dei prodotti, il fatturato
-- TABELLE sales, product

SELECT ProductName, SUM(Tot_paid) as Tot_Revenue, year (Date_transaction) as year
FROM sales join product on sales.ProductID = product.ProductID
GROUP BY ProductName, year(Date_transaction);

/*DOMANDA 3: Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. */

-- INPUT fatturato totale, stato
-- OUTPUT fatturato, paese, anno
-- TABELLE Region, Sales, 

SELECT country, YEAR(Date_transaction) AS year, SUM(tot_paid) AS tot_revenue
FROM Region JOIN sales ON Region.RegionID = Sales.RegionID
GROUP BY country, YEAR(Date_transaction)
ORDER BY YEAR, tot_revenue DESC;


/*DOMANDA 4 Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? */

-- INPUT cattegoria più venduto
-- OUTPUT nome cattegoria più venduto
-- TABELLE product, sales

SELECT category, SUM(quantity) AS TotQuantity
FROM sales JOIN product on sales.productId = product.productID
GROUP BY category
ORDER BY TotQuantity DESC
LIMIT 1;

/*DOMANDA 5 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. */
-- APPROCIO 1 LEFT JOIN

SELECT P.ProductID, P.ProductName, p.category
FROM Product P
LEFT JOIN Sales S ON P.ProductID = S.ProductID
WHERE S.ProductID = NULL;

-- APPROCIO 2 SUBQUERY
SELECT productID, productName, category
FROM product
WHERE productID NOT IN (SELECT sales.productID FROM sales);

/*DOMANDA 6 Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).*/

SELECT P.category, P.ProductName, MAX(S.Date_transaction) AS LastSaleDate
FROM Product P
JOIN Sales S ON P.ProductID = S.ProductID
GROUP BY P.ProductID,P.ProductName
ORDER BY LastSaleDate DESC;





